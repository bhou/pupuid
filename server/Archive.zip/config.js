/**
 * Created by BHOU on 6/20/14.
 */

module.exports = {
//  mongostore: {
//    db: 'certifoto',
//    host: 'ds031319.mongolab.com',
//    port: '31319',
//    username: 'test',
//    password: 'test'
//  },


//  mongostore: {
//    db: 'openu',
//    host: 'localhost',
//    port: '27017',
//    username: '',
//    password: ''
//  },
  mongostore: {
    db: 'IbmCloud_i8p66lsa_7a6id5k1',
    host: 'ds035257.mongolab.com',
    port: '35257',
    username: 'IbmCloud_i8p66lsa_7a6id5k1_vlndlb5l',
    password: 'c1iaAj1D5CoLqYY-n6qmvyyddBawRTjh'
  },

  bluemix: {
    enable: true
  },

  logger: {
    file: 'pupuid-server.log',
    level: 'info'
  }
}